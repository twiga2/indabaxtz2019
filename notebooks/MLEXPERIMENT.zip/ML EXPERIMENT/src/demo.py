print(
 "davis david"     
)